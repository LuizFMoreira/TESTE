# Artefatos do projeto

Este diretório mantém os artefatos do projeto. 


Liste os artefatos produzidos, com suas localizações e descrição do conteúdo.

Por exemplo, pode-se criar um diretório "atas", que seria descrito da seguinte forma:
* `/atas`
	* **Ata_xx_ago_20xx.docx**: Ata de reunião do dia xx de agosto de 20xx.

Assim, sucessivamente para outros artefatos como `interfaces de usuário` e `modelos`, etc.