# [DetalhesPrata]

[Escreva um ou dois  parágrafo resumindo o objetivo do seu projeto.]

## Alunos integrantes da equipe

* [Josue Carlos Goulart Dos Reis]
* [Kelvyn Dantas Leal]
* [Luiz Fernando Batista Moreira]
* [Miguel Gomes do Nascimento]
* [Nicolas Kiffer de Oliveira Soares]

## Professores responsáveis

* [Eveline Alonso Veloso]
* [Juliana Amaral Baroni de Carvalho]

## Instruções de utilização

[Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.]
